﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Everything has been taking longer than anticipated. Literally just down to inexperience. Estimating 2 hours to add in functions for this week
// however that will probably change as things go along.
//Quite a bit of difficulty getting anything done that works, did better getting an array to work as a standalone print but trying to find
//a way to incorporate into my projects.
namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string path = @"C:\\New Text Document.txt";
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            {
                if (txtRate.Text == "")
                    MessageBox.Show("Please enter a number in Hourly Rate");
            }
            {
                if (txtHours.Text == "")
                    MessageBox.Show("Please enter a number in Hours Worked");
            }
            double grosspay = 0;
            grosspay = Convert.ToDouble(this.txtRate.Text) * Convert.ToDouble(this.txtHours.Text);
            lblGrossPay.Text = grosspay.ToString();

            File.WriteAllText(path, lblGrossPay.Text);

            {
                int result;
                string str = txtHours.Text;
                if (int.TryParse(str, out result))
                {
                    MessageBox.Show("this is a valid entry");

                }
                else
                {
                    MessageBox.Show("NOT a valid entry");
                }
                try
                {
                    result = int.Parse(str);
                }
                catch
                {
                    MessageBox.Show("Not a valid entry, please try again");
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtHours.Text = "";
            this.txtRate.Text = "";
            this.lblGrossPay.Text = "";
            this.txtSales.Text = "";
            this.txtYears.Text = "";
            this.textBox1.Text = "";
            this.lblDays.Text = "";
            this.lblCommissions.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void vacationDaysEarnedToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                if (txtRate.Text == "")
                    MessageBox.Show("Please enter a number in Total Sales");
            }
            double grosspay = 0;
            grosspay = Convert.ToDouble(this.txtSales.Text) * .10;
            lblCommissions.Text = grosspay.ToString();

            File.WriteAllText(path, lblCommissions.Text);
            {
                int result;
                string str = txtSales.Text;
                if (int.TryParse(str, out result))
                {
                    MessageBox.Show("this is a valid entry");

                }
                else
                {
                    MessageBox.Show("NOT a valid entry");
                }
                try
                {
                    result = int.Parse(str);
                }
                catch
                {
                    MessageBox.Show("Not a valid entry, please try again");
                }
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate3_Click(object sender, EventArgs e)
        {
            double days = 0;
            days = Convert.ToDouble(this.txtYears.Text) * 5;
            lblDays.Text = days.ToString();

            File.WriteAllText(path, lblDays.Text);
            {
                int result;
                string str = txtYears.Text;
                if (int.TryParse(str, out result))
                {
                    MessageBox.Show("this is a valid entry");

                }
                else
                {
                    MessageBox.Show("NOT a valid entry");
                }
                try
                {
                    result = int.Parse(str);
                }
                catch
                {
                    MessageBox.Show("Not a valid entry, please try again");
                }
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int result;
            string str = textBox1.Text;
            if (int.TryParse(str, out result))
            {
                MessageBox.Show("this is a valid entry");

            }
            else
            {
                MessageBox.Show("NOT a valid entry");
            }
            try
            {
                result = int.Parse(str);
            }
            catch
            {
                MessageBox.Show("Not a valid entry, please try again");
            }
        }

        private void btnRandom_Click(object sender, EventArgs e)
        {
            lblNumber.Text = r().ToString();
            double r()
            {
                Random generator = new Random();
                return generator.Next(0, 100);
            }
        }

        private void btnArray_Click(object sender, EventArgs e)
        {
            if (txtHours.Text.Length > 0)
            {
                lblArray.Text = string.Empty;
                string[] arr = txtHours.Text.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < arr.Length; i++)
                    lblArray.Text += arr[i] + "\r\n";
            }
            else
            {
                MessageBox.Show("Please enter a number larger than zero.");
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
           
            {
                int[] arrayname = new int[5];/*arrayname is an array of 5 integer [5] mean in array [0],[1],[2],[3],[4],[5] because array starts with zero*/
                int i, j;


                /*initialize elements of array arrayname*/
                for (i = 0; i < 5; i++)
                {
                    arrayname[i] = i + 100;
                }

                /*output each array element value*/
                for (j = 0; j < 5; j++)
                {
                    Console.WriteLine("Element and output value [{0}]={1}", j, arrayname[j]);
                }
                Console.ReadKey();
        }
    }
 }

