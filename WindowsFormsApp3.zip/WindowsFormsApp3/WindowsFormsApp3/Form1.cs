﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double grosspay = 0;
            grosspay = Convert.ToDouble(this.txtRate.Text) * Convert.ToDouble(this.txtHours.Text);
            lblGrossPay.Text = grosspay.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtHours.Text = "";
            this.txtRate.Text = "";
            this.lblGrossPay.Text = "";
            this.txtSales.Text = "";
            this.txtYears.Text = "";
            this.textBox1.Text = "";
            this.lblDays.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void vacationDaysEarnedToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            double grosspay = 0;
            grosspay = Convert.ToDouble(this.txtSales.Text) * .10;
            lblCommissions.Text = grosspay.ToString();

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate3_Click(object sender, EventArgs e)
        {
            double days = 0;
            days = Convert.ToDouble(this.txtYears.Text) * 5;
            lblDays.Text = days.ToString();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int result;
            string str = textBox1.Text;
            if (int.TryParse(str,out result))
            {
                MessageBox.Show("this is a valid entry");

            }
            else
            {
                MessageBox.Show("NOT a valid entry");
            }
            try
            {
                result = int.Parse(str);
            }
            catch
            {
                MessageBox.Show("Not a valid entry, please try again");
            }
        }
    }
    }

